package poo.ayudantia6;

import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.util.ArrayList;

public class ControladorCocinero {
    private Button [] btns;
    private Label [] labelsCocinadas;
    private Label [] labelsPendientes;
    private Label [] labelsInventario;
    private Empleado.Cocinero cocinero;
    private Empleado.Cajero cajero;
    private int [] contadorReporte;

    public ControladorCocinero(Button [] btns, Label [] labelsCocinadas, Label [] labelsPendientes, Label [] labelsInventario, Empleado.Cocinero cocinero, Empleado.Cajero cajero) {
        this.btns = btns;;
        this.labelsCocinadas = labelsCocinadas;
        this.labelsPendientes = labelsPendientes;
        this.labelsInventario = labelsInventario;
        this.cocinero = cocinero;
        this.cajero = cajero;
        contadorReporte = new int[4];

        for (int i = 0; i < 4; i++) {
            contadorReporte[i] = 0;
        }

        manejoEventos();
    }

    private void manejoEventos() {

        //Manejo de todos los botones
        for (int i = 0; i < 4; i++) {
            final int index = i; //En expresiones lambda los indices deben ser final.
            //Se pulsa el botón
            btns[i].setOnAction(e -> {
                //Invocación del metodo cocinar
                cocinero.cocinar(index + 1);
                ArrayList<Producto> inventario = cocinero.getInventario();

                // Verificar si hay suficientes ingredientes
                int [] cantidadesRequeridas = cocinero.getCantidadesNecesarias(index);
                boolean suficientes = true;
                for (int j = 0; j < 6; j++) {
                    int cantidadDisponible = inventario.get(j).getCantidad();

                    //Salir si no hay suficientes cantidades
                    if (cantidadDisponible < cantidadesRequeridas[j]) {
                        suficientes = false;
                        break;
                    }
                }

                if (suficientes) {
                    // Restar cantidades del inventario
                    for (int j = 0; j < 6; j++) {
                        inventario.get(j).descontarProducto(cantidadesRequeridas[j]);
                    }

                        // Actualizar etiquetas de inventario
                        for (int k = 0; k < 6; k++) {
                            final int indexInventory = k;
                            int nIngrediente = inventario.get(indexInventory).getCantidad();

                            String textoActual = labelsInventario[indexInventory + 1].getText();
                            String [] separados = textoActual.split(":");
                            labelsInventario[indexInventory + 1].setText(separados[0] + ": " + nIngrediente);
                        }

                        // Reporte
                        contadorReporte[index]++;
                        String textoAntes = labelsCocinadas[index + 1].getText();
                        String [] separadosReporte = textoAntes.split(":");
                        labelsCocinadas[index].setText(separadosReporte[0] + ": " + contadorReporte[index]);

                        // Disminuir hamburguesa pendientes
                        String textoActual = labelsPendientes[index + 1].getText();
                        String [] separadosActual = textoActual.split(":");

                        //El método trim() elimina los espacios al inicio y al final de un String
                        int cont = Integer.parseInt(separadosActual[separadosActual.length - 1].trim());
                        labelsPendientes[index + 1].setText(separadosActual[0] + ": " + (cont - 1));
                }

            });
        }
    }




}