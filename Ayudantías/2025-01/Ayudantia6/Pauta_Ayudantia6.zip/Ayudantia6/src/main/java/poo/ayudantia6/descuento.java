package poo.ayudantia6;

public interface descuento{
    void descontarProducto(int cantidadNecesaria);
    boolean checkProducto();
    void alertaCantidad();
}
