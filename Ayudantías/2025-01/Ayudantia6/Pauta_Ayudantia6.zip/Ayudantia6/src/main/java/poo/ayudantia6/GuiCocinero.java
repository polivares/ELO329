package poo.ayudantia6;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.*;

import java.io.IOException;

public class GuiCocinero extends Application {

    private Empleado [] staff;

    //Por el contexto, basta que este sea un atributo de la clase
    //pero una buena práctica sería que todos los elementos gráficos sean atributos
    //privados de la clase.
    private Label [] pendientes;


    //Método que conecta las etiquetas de vendidos y pendiente en ambas vistas
    public void aumentarPendiente(int index, int cantidad) {
        String textoActual = pendientes[index + 1].getText();
        String [] separados = textoActual.split(":");

        // Aumentar y actualizar
        pendientes[index + 1].setText(separados[0] + ": " + cantidad);

    }
    @Override
    public void start(Stage stage) throws IOException {
        staff = new Empleado[2];
        staff[0] = new Empleado("Bob Esponja", "Part-time", 250000);
        staff[1] = new Empleado("Calamardo Tentaculos", "Full-time", 6000000);

        Empleado.Cocinero cocinero = staff[0].new Cocinero();
        Empleado.Cajero cajero = staff[1].new Cajero();

        // Inicializar inventario
        cocinero.agregarProducto("Queso Cheddar", 55, false, "Lácteo");
        cocinero.agregarProducto("Queso Mozarella", 30, false, "Lácteo");
        cocinero.agregarProducto("Lechuga", 29, false, "Vegetales");
        cocinero.agregarProducto("Tomate", 43, false, "Vegetales");
        cocinero.agregarProducto("Pepinillos", 39, false, "Vegetales");
        cocinero.agregarProducto("Pan de sésamo", 45, false, "Panes");
        cocinero.agregarProducto("Hamburguesas de cangrejo", 37, true, "Carnes");

        //Panes
        BorderPane mainPane = new BorderPane();
        VBox btnsPane = new VBox();
        HBox upperBtns = new HBox();
        HBox lowerBtns = new HBox();
        VBox pedidos = new VBox();
        VBox inventario = new VBox();
        HBox reporte = new HBox();

        //Imagenes
        Image clasica = new Image(getClass().getResource("/imgs/CB_clasica.jpeg").toExternalForm());
        Image doble = new Image(getClass().getResource("/imgs/CB_doble.jpeg").toExternalForm());
        Image cheese = new Image(getClass().getResource("/imgs/CB_vegan.jpeg").toExternalForm());
        Image vegan = new Image(getClass().getResource("/imgs/CB_queso.jpeg").toExternalForm());

        //Imageviews
        ImageView vistaClasica = new ImageView(clasica);
        ImageView vistaDoble = new ImageView(doble);
        ImageView vistaCheese = new ImageView(cheese);
        ImageView vistaVegan = new ImageView(vegan);

        //Ajuste ImageViews
        vistaClasica.setFitWidth(300);
        vistaClasica.setPreserveRatio(true);
        vistaClasica.setSmooth(true);

        vistaDoble.setFitWidth(300);
        vistaDoble.setPreserveRatio(true);
        vistaDoble.setSmooth(true);

        vistaVegan.setFitWidth(300);
        vistaVegan.setPreserveRatio(true);
        vistaVegan.setSmooth(true);

        vistaCheese.setFitWidth(300);
        vistaCheese.setPreserveRatio(true);
        vistaCheese.setSmooth(true);

        //Botones
        Button [] btns = new Button[4];

        //Botón de la cangreburger clásica
        btns[0] = new Button();
        btns[0].setGraphic(vistaClasica);

        //Botón de la cangreburger doble
        btns[1] = new Button();
        btns[1].setGraphic(vistaDoble);

        //Botón de la CangreCheese
        btns[2] = new Button();
        btns[2].setGraphic(vistaCheese);

        //Botón de la CangreVegan
        btns[3] = new Button();
        btns[3].setGraphic(vistaVegan);

        //Labels
        Label [] cocinadas= new Label[5];
        cocinadas[0] = new Label("REPORTE:");
        cocinadas[1] = new Label("Cangreburger Clásica cocinadas: 0");
        cocinadas[2] = new Label("Doble Cangreburger cocinadas: 0");
        cocinadas[3] = new Label("CangreVegan cocinadas: 0");
        cocinadas[4] = new Label("CangreCheese cocinadas: 0");

        pendientes = new Label[5];
        pendientes[0] = new Label("PEDIDOS PENDIENTES:");
        pendientes[1] = new Label("Cangreburgers clásicas: 0");
        pendientes[2] = new Label("Dobles Cangreburgers: 0");
        pendientes[3] = new Label("CangreVegan: 0");
        pendientes[4] = new Label("CangreCheese: 0");

        //Pequeño hardcode para la vista, debo reemplazar más adelante
        Label [] inventory = new Label[8];

        /**
         * Indices:
         * Queso Cheddar: 0
         * Queso Mozarella: 1
         * Lechucha: 2
         * Tomate: 3
         * Pepinillos: 4
         * Pan de sésamo: 5
         * Ingrediente secreto: 6
         */
        inventory[0] = new Label("INVENTARIO");
        inventory[1] = new Label("Queso Cheddar: " + cocinero.getInventario().get(0).getCantidad());
        inventory[2] = new Label("Queso Mozarella: " + cocinero.getInventario().get(1).getCantidad());
        inventory[3] = new Label("Lechuga: " + cocinero.getInventario().get(2).getCantidad());
        inventory[4] = new Label("Tomate: " + cocinero.getInventario().get(3).getCantidad());
        inventory[5] = new Label("Pepinillos: " + cocinero.getInventario().get(4).getCantidad());
        inventory[6] = new Label("Pan de sésamo: " + cocinero.getInventario().get(5).getCantidad());
        inventory[7] = new Label("Ingrediente secreto: " + cocinero.getInventario().get(6).getCantidad());

        //Panes secundarios}

        //Pane botones
        upperBtns.getChildren().add(btns[0]);
        upperBtns.getChildren().add(btns[1]);
        lowerBtns.getChildren().add(btns[2]);
        lowerBtns.getChildren().add(btns[3]);

        btnsPane.getChildren().add(upperBtns);
        btnsPane.getChildren().add(lowerBtns);

        //Pane Pedidos
        for(int index = 0; index < 5; index++){
            pedidos.getChildren().add(pendientes[index]);
        }

        //Pane Reporte
        for(int index = 0; index < 5; index++){
            reporte.getChildren().add(cocinadas[index]);
        }
        reporte.setAlignment(Pos.CENTER);
        reporte.setSpacing(20);

        //Pane inventario
        for(int index = 0; index < 8; index++){
            inventario.getChildren().add(inventory[index]);
        }

        mainPane.setCenter(btnsPane);
        mainPane.setBottom(reporte);
        mainPane.setLeft(pedidos);
        mainPane.setRight(inventario);

        Scene escena = new Scene(mainPane, 1000, 500);
        stage.setScene(escena);
        stage.setHeight(800);
        stage.setWidth(1000);
        stage.setTitle("Cocinero GUI");
        stage.show();

        //GUI Cajero
        GuiCajero vistaCajero = new GuiCajero(this);
        Stage cajeroGUI = new Stage();
        Scene cajeroScene = vistaCajero.crearScene();
        cajeroGUI.setScene(cajeroScene);
        cajeroGUI.setTitle("Cajero GUI");
        cajeroGUI.show();

        ControladorCocinero controller = new ControladorCocinero(btns, cocinadas, pendientes, inventory, cocinero, cajero);

    }

    public static void main(String[] args) {
        launch();
    }
}