package poo.ayudantia6;

import javafx.scene.control.Label;
import javafx.scene.control.Button;

public class ControladorCajero {
    private Button [] btns;
    private Label [] labels;
    private int [] count;
    private GuiCocinero refCocinero;

    //Constructor
    public ControladorCajero(Button [] btns, Label [] labels, GuiCocinero refCocinero) {
        this.btns = btns;
        this.labels = labels;
        this.count = new int[4];
        this.refCocinero = refCocinero;

        for(int i = 0; i < 4; i++){
            count[i] = 0;
        }

        manejoEventos();
    }

    //Controlador de botones
    private void manejoEventos() {
        for (int i = 0; i < btns.length; i++) {
            int index = i;
            btns[i].setOnAction(event -> {
                count[index]++;
                labels[index].setText(btns[index].getText() + "s vendidas: " + count[index]);
                refCocinero.aumentarPendiente(index, count[index]);
            });

        }
    }

}

