package com.example.ayudantia5;

import javafx.scene.control.Label;
import javafx.scene.control.Button;

public class Controlador {
    private Button [] btns;
    private Label [] labels;
    private int [] count;

    public Controlador(Button [] btns, Label [] labels){
        this.btns = btns;
        this.labels = labels;
        this.count = new int[4];

        for(int i = 0; i < 4; i++){
            count[i] = 0;
        }

        manejoEventos();
    }
    private void manejoEventos() {
        for (int i = 0; i < btns.length; i++) {
            int index = i;
            btns[i].setOnAction(event -> {
                count[index]++;
                labels[index].setText(btns[index].getText() + "s vendidas: " + count[index]);
            });

        }
    }

}

