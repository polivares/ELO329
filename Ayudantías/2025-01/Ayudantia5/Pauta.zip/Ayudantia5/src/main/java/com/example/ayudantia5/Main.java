package com.example.ayudantia5;
import javafx.application.Application;
import javafx.scene.image.Image;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;

//Vista de la GUI
public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        //Pane
        GridPane mainPane = new GridPane();
        VBox [] cuadrantes = new VBox[4];

        //Botones
        Button [] btns = new Button[4];
        btns[0] = new Button("Cangreburger Clásica");
        btns[1] = new Button("Doble Cangreburger");
        btns[2] = new Button("CangreVegan");
        btns[3] = new Button("CangreCheese");

        //Imagenes
        Image imgClasica = new Image(getClass().getResource("/imgs/CB_clasica.jpeg").toExternalForm());
        Image imgDoble = new Image(getClass().getResource("/imgs/CB_doble.jpeg").toExternalForm());
        Image imgVegan = new Image(getClass().getResource("/imgs/CB_vegan.jpeg").toExternalForm());
        Image imgCheese = new Image(getClass().getResource("/imgs/CB_queso.jpeg").toExternalForm());

        //ImageViews
        ImageView [] views = new ImageView[4];
        views[0] = new ImageView(imgClasica);
        views[1] = new ImageView(imgDoble);
        views[2] = new ImageView(imgVegan);
        views[3] = new ImageView(imgCheese);

        //Labels
        Label [] etiquetas = new Label[4];
        etiquetas[0] = new Label("Cangreburger Clásica vendidas: 0");
        etiquetas[1] = new Label("Doble Cangreburger vendidas: 0");
        etiquetas[2] = new Label("CangreVegan vendidas: 0");
        etiquetas[3] = new Label("CangreCheese vendidas: 0");

        //Creación de cuadrantes y asignación a mainPane
        for(int i = 0; i <= 3; i++){
            cuadrantes[i] = new VBox();

            //Ajuste del tamaño de las imagenes
            views[i].setFitWidth(425);
            views[i].setPreserveRatio(true);
            views[i].setSmooth(true);

            //Asignación de elementos a los VBox
            cuadrantes[i].getChildren().add(views[i]);
            cuadrantes[i].getChildren().add(btns[i]);
            cuadrantes[i].getChildren().add(etiquetas[i]);

            // Coloca cada VBox en su respectivo cuadrante: 0,0 - 1,0 - 0,1 - 1,1
            int col = i % 2;
            int row = i / 2;
            mainPane.add(cuadrantes[i], col, row);
            mainPane.setVgap(20);
            mainPane.setHgap(80);
        }

        Controlador controller = new Controlador(btns, etiquetas);

        Scene scene = new Scene(mainPane,1000, 1000);
        stage.setTitle("Caja GUI");
        stage.setScene(scene);
        stage.setWidth(1000);
        stage.setHeight(1000);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}