// Clase encargada de la conexión entre Interfaz Gráfica y Mascota
public class Controller {
    // Ejemplos de algunos atributos
    private Mascota mi_mascota;
    private Inventario inventario;
    private boolean estado_luz = true;
    private Timeline timeline;
    // Agregar atributos, constructor y métodos que ud. considere necesario

    
}
