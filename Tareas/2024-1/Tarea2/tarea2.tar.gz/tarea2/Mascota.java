// Clase que define a la mascota
public class Mascota {
    public Mascota(String nombre) {
        this.nombre = new SimpleStringProperty(nombre);
        this.edad = new SimpleDoubleProperty(0.0);
        this.salud = new SimpleFloatProperty(100);
        this.energia = new SimpleFloatProperty(100);
        this.felicidad = new SimpleFloatProperty(50);
        this.estadoText = new SimpleStringProperty("Neutro");
    }

    
    // Ejemplos de métodos que podrían ser de utilidad.
    
    // Aplicar un item en la Mascota
    public void useItem(Item item){
    }

    // Método encargado de los efectos de dormir en la Mascota
    public void sleep(){
    }

    // Método encargado de modificar los indicadores por cada aumento de tiempo
    public void timeStep(){

    }


    // Ejemplos de getter y setter para una de las propiedades (nombre)
    public StringProperty getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }
    
    
    
    // Atributos de tipo Property, para ser conectados con la interfaz
    private StringProperty nombre;
    private StringProperty estadoText;
    private DoubleProperty edad;
    private FloatProperty salud;
    private FloatProperty energia;
    private FloatProperty felicidad;

    // Máximos valores para los indicadores
    public final int SALUD_MAXIMA = 100;
    public final int ENERGIA_MAXIMA = 100;
    public final int FELICIDAD_MAXIMA = 100;
}
