/**
 * Aplicación JavaFX
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        // Si utiliza las bibliotecas de JavaFX, acá debe recrear
        // la interfaz gráfica.
        
        // Si utiliza SceneBuilder, acá deberá hacer la carga (load) del
        // archivo .fxml para su posterior uso.
        
    }

    public static void main(String[] args) {
        launch();
    }

}
