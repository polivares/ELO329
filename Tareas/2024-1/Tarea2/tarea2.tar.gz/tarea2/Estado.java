public enum Estado {
    Neutro,
    Feliz, 
    Triste, 
    Hambriento, 
    Enojado, 
    Cansado,
    Muerto
}
