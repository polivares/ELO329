public abstract class Item {


    public abstract void printItemAplicado();

    /* Completar código de la clase */
}


