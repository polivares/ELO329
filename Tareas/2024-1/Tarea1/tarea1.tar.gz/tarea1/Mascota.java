public class Mascota {
    /* Completar con los métodos, atributos y constructor de Mascota 
    dependiendo de la etapa */
}
